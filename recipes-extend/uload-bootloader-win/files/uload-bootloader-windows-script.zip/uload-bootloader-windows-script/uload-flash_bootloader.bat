@echo off
REM : Copyright (C) 2022 Avnet
REM : Copyright (C) 2023 Renesas Electronics
REM : This BAT script used to call TTL(Tera Term Language) script to program bootloader image.

set WORK_DIR=%~dp0
set TOOLS_PATH=%WORK_DIR%tools

REM : Parser configure file
for /f "tokens=1,2 delims==" %%a in (config.ini) do (
  if %%a==COM                 set COM=%%b
)

REM : Lauch Tera Term Macro script to start program
set ARGS=%COM% %MEDIA% %WORK_DIR%
start %TOOLS_PATH%\ttpmacro.exe /I %TOOLS_PATH%\uload-flash_bootloader.ttl %ARGS%