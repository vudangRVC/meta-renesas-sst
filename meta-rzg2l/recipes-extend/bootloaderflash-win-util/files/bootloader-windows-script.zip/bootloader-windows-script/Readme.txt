# Bootloader Programming/Flashing Procedure for RZ SBC board

In order to make development more convenient, we have designed some small script programs for programming programs. 
This section will introduce the relevant tools and specific steps for using these small script programs to program QSPI Flash and eMMC (Not supported yet).

## Use flash_bootloader.bat to program Bootloader Images to QSPI Flash

Please following below steps:

1.Put all bootloader images to the folder /images (optional).
The default package includes all necessary images for flashing bootloader. If you intend to use your own bootloaders, you should prepare them in this folder.

2.Connect debug serial (SCIF0 - TXD,RXD,GND) to Windows PC, then change switches to enter SCIF download mode.

3.Edit **config.ini** by any editor on Windows (such as notepad) to configure the parameters according to your development environment.
Make sure your COM port when connecting debug serial is shown in Device Manager (Ports (COM&LPT)).

```
[COMMON]
COM=6

[BOOTLOADER]
FLASH_WRITER=Flash_Writer_SCIF_rzpi.mot
FILE_BL2=bl2_bp-rzpi.srec
FILE_FIP=fip-rzpi.srec
```

4.Run **flash_bootloader.bat** and choose the program media (QSPI Flash - 2). It will automatically launch **Tera Term** program and wait for system power up.

5.Power on the board with a 5V, Type-C interface power (to J10). It will start to flash bootloader images into QSPI flash.

Wait for the script running automatically, and no input or operation is required during this period. After completing the process, the Teraterm will disconnect and show 'disconnected' in the title bar. Then you can set RZ SBC board to boot from QSPI as your needs.
