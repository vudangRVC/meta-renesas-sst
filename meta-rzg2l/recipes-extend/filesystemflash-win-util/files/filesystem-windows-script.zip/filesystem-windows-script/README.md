# Root filesystem Programming/Flashing Procedure for RZ SBC board on Windows

This section will introduce the relevant tools and specific steps for using these small script programs to program filesystem image.

## Use flash_filesystem.bat to program Filesystem Image to SD Card

Please following below steps:

1.Put a filesystem image (`wic` file) to the folder `/images` (optional).

The default package includes a required filesystem image for flashing. If you intend to use your own filesystem image, you should prepare it in this folder.

2.Connect debug serial (SCIF0 - TXD,RXD,GND) to Windows PC.

3.Connect Ethernet Port 0 (J7) on RZG2L SBC board to network on Windows PC by network cable, then power on the board and enter U-Boot console.

4.Edit **config.ini** by any editor on Windows (such as notepad) to configure the parameters according to your development environment.

Make sure your COM port when connecting debug serial is shown in Device Manager (Ports (COM&LPT)).
And an ethernet connection between the board and Windows PC.

```
[COMMON]
COM=6
IPADDR=169.254.213.175

[SYSTEM]
FILE_SYSIMG=core-image-qt-rzpi.wic
```

**Note: The IP address `IPADDR` in `config.ini` should be different (but still same subnet) from the one on Windows PC. This IP addess is used assigned to the board.**

For example: the IP address on Windows PC is `169.254.213.176`. So the IP address `IPADDR` which is assigned to the board should be `169.254.213.175`


5.Power off the board.

6.Run **flash_filesystem.bat**. It will automatically launch **Tera Term** program and wait for system power up.

7.Power on the board with a 5V, Type-C interface power (to J10). It will start to flash filesystem image into SD Card.

Wait for the script running automatically, and no input or operation is required during this period. After finishing, you can **press any key to exit the BAT script** and close the **Tera Term** program.
Then you need to power cycle the board to boot with the filesystem image that you just flashed.

