# Bootloader Programming/Flashing Procedure for RZ SBC board

In order to make development more convenient, we have designed some small script programs for programming programs. 
This section will introduce the relevant tools and specific steps for using these small script programs to program QSPI Flash and eMMC (Not supported yet).

## Use flash_bootloader.bat to program Bootloader Images to QSPI Flash

Please following below steps:

1.Running the script

### Basic Usage

To run the script without passing any arguments, simply execute the following command:

```
./flash_bootloader.bat
```

When no arguments are provided, the script will use the following default file paths for the images:

- Flash Writer Image: </path/to/your/package>/target/images/Flash_Writer_SCIF_rzpi.mot
- BL2 Image: </path/to/your/package>/target/images/bl2_bp-rzpi.srec
- FIP Image: </path/to/your/package>/target/images/fip-rzpi.srec

Ensure that these files are present in the current directory before executing the script.

### Custom Usage

If you want to specify different file paths or change the serial port settings or images file, you can pass the arguments as shown below:

```
./flash_bootloader.bat --COM 4 --image_writer /path/to/Flash_Writer_SCIF_rzpi.mot --image_bl2 /path/to/bl2_bp-rzpi.srec --image_fip /path/to/fip-rzpi.srec
```

#### Arguments
- **--serial_port**: Serial port to use for communication with the board. Default is /dev/ttyUSB0.
- **--image_writer**: Path to the Flash Writer image.
- **--image_bl2**: Path to the BL2 image.
- **--image_fip**: Path to the FIP image.

#### Example command

```
.\flash_bootloader.bat --COM 4 --image_writer D:\rz-sbc\rzpi\custom_images\Flash_Writer_SCIF_rzpi.mot --image_bl2 D:\rz-sbc\rzpi\custom_images\bl2_bp-rzpi.srec --image_fip D:\rz-sbc\rzpi\custom_images\fip-rzpi.srec
```

If which arguments is not passed, the default value will be used.

2.Connect debug serial (SCIF0 - TXD,RXD,GND) to Windows PC, then change switches to enter SCIF download mode.

3.Edit **config.ini** by any editor on Windows (such as notepad) to configure the parameters according to your development environment.
Make sure your COM port when connecting debug serial is shown in Device Manager (Ports (COM&LPT)).

```
[COMMON]
COM=6

[BOOTLOADER]
FLASH_WRITER=Flash_Writer_SCIF_rzpi.mot
FILE_BL2=bl2_bp-rzpi.srec
FILE_FIP=fip-rzpi.srec
```

4.Run **flash_bootloader.bat** and choose the program media (QSPI Flash - 2). It will automatically launch **Tera Term** program and wait for system power up.

5.Power on the board with a 5V, Type-C interface power (to J10). It will start to flash bootloader images into QSPI flash.

Wait for the script running automatically, and no input or operation is required during this period. After completing the process, the Teraterm will disconnect and show 'disconnected' in the title bar. Then you can set RZ SBC board to boot from QSPI as your needs.
