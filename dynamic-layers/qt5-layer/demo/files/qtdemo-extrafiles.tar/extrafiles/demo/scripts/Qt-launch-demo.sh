#!/bin/sh

/usr/bin/qt5/qmlscene /usr/share/qt5-launch-demo/main_autorun.qml --fullscreen &
