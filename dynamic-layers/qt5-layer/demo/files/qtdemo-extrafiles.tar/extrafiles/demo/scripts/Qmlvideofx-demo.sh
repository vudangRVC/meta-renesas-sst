#!/bin/sh

/usr/share/qt5/examples/multimedia/video/qmlvideofx/qmlvideofx --fullscreen &
