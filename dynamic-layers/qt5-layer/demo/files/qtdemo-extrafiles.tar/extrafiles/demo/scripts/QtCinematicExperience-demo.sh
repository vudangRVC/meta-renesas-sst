#!/bin/sh

/usr/share/cinematicexperience-1.0/Qt5_CinematicExperience --fullscreen &
