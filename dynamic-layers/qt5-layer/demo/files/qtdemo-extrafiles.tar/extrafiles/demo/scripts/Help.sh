#!/bin/sh

/usr/share/qt5/examples/webkitwidgets/browser/browser /home/root/info/renesas_rzg2l_info.html &
